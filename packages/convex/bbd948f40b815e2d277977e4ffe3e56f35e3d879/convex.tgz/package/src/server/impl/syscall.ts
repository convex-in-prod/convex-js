import { ConvexError } from "../../values/errors.js";
import { jsonToConvex } from "../../values/value.js";

declare const Convex: {
  syscall: (op: string, jsonArgs: string) => string;
  asyncSyscall: (op: string, jsonArgs: string) => Promise<string>;
  syscallObjectArgs?: (op: string, args: Record<string, any>) => string;
  asyncSyscallObjectArgs?: (
    op: string,
    args: Record<string, any>,
  ) => Promise<string>;
  asyncSyscallValueArgs?: (
    op: string,
    args: Record<string, unknown>,
  ) => Promise<unknown>;
  jsSyscall: (op: string, args: Record<string, any>) => any;
};
/**
 * Perform a syscall with a JSON-encodable object and parse its JSON response.
 * The runtime may accept the object directly or require a JSON string.
 * If one of your arguments is a Convex value, you must call `convexToJson` on it
 * before passing it to this function, and if the return value has a Convex value, you're
 * also responsible for calling `jsonToConvex`: This layer only deals in JSON.
 */

export function performSyscall(op: string, arg: Record<string, any>): any {
  if (typeof Convex === "undefined" || Convex.syscall === undefined) {
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. " +
        "Did you mean to use `useQuery` or `useMutation` to call a Convex function?",
    );
  }
  const resultStr =
    Convex.syscallObjectArgs === undefined
      ? Convex.syscall(op, JSON.stringify(arg))
      : Convex.syscallObjectArgs(op, arg);
  return JSON.parse(resultStr);
}

export async function performAsyncSyscall(
  op: string,
  arg: Record<string, any>,
): Promise<any> {
  if (typeof Convex === "undefined" || Convex.asyncSyscall === undefined) {
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. " +
        "Did you mean to use `useQuery` or `useMutation` to call a Convex function?",
    );
  }
  let resultStr;
  try {
    resultStr =
      Convex.asyncSyscallObjectArgs === undefined
        ? await Convex.asyncSyscall(op, JSON.stringify(arg))
        : await Convex.asyncSyscallObjectArgs(op, arg);
  } catch (e: any) {
    // Rethrow the exception to attach stack trace starting from here.
    // If the error came from JS it will include its own stack trace in the message.
    // If it came from Rust it won't.

    // This only happens if we're propagating ConvexErrors
    if (e.data !== undefined) {
      const rethrown = new ConvexError(e.message);
      rethrown.data = jsonToConvex(e.data);
      throw rethrown;
    }
    throw new Error(e.message);
  }
  return JSON.parse(resultStr);
}

/** The Wasm value ABI returns SDK-visible values; V8 keeps the JSON syscall contract. */
export async function performAsyncValueSyscall<T>(
  op: string,
  valueArgs: Record<string, unknown>,
  jsonArgs: () => Record<string, unknown>,
  fromJson: (value: any) => T,
): Promise<T> {
  if (
    typeof Convex === "undefined" ||
    Convex.asyncSyscallValueArgs === undefined
  ) {
    return fromJson(await performAsyncSyscall(op, jsonArgs()));
  }
  try {
    return (await Convex.asyncSyscallValueArgs(op, valueArgs)) as T;
  } catch (e: any) {
    if (e.data !== undefined) {
      const rethrown = new ConvexError(e.message);
      rethrown.data = e.data;
      throw rethrown;
    }
    throw new Error(e.message);
  }
}

/**
 * Call into a "JS" syscall. Like `performSyscall`, this calls a dynamically linked
 * function set up in the Convex function execution. Unlike `performSyscall`, the
 * arguments do not need to be JSON-encodable and neither does the return value.
 *
 * @param op
 * @param arg
 * @returns
 */
export function performJsSyscall(op: string, arg: Record<string, any>): any {
  if (typeof Convex === "undefined" || Convex.jsSyscall === undefined) {
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. " +
        "Did you mean to use `useQuery` or `useMutation` to call a Convex function?",
    );
  }
  return Convex.jsSyscall(op, arg);
}
