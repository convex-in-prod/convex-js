export const version = "1.43.0+convex-in-prod.a1c6710aa7f7";
